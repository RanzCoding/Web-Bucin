# WebBucin-V2
Web Bucin V2 khusus buat orang tercinta &amp; tersayang.

# Demo Site
 <a href="https://wafarifki.github.io/WebBucin-V2/">https://wafarifki.github.io/WebBucin-V2/</a>

# List Repo Web Bucin
- <a target="_blank" href="https://github.com/wafarifki/WebBucin-V1">https://github.com/wafarifki/WebBucin-V1</a>
- <a target="_blank" href="https://github.com/wafarifki/WebBucin-V3">https://github.com/wafarifki/WebBucin-V3</a>
- <a target="_blank" href="https://github.com/wafarifki/WebBucin-V4">https://github.com/wafarifki/WebBucin-V4</a>
- <a target="_blank" href="https://github.com/wafarifki/WebBucin-V5">https://github.com/wafarifki/WebBucin-V5</a>
- <a target="_blank" href="https://github.com/wafarifki/WebBucin-V6">https://github.com/wafarifki/WebBucin-V6</a>

# Let's connect with me!
<p>
    <a href="https://wafarifki.github.io" target="_blank"><img src="https://img.shields.io/badge/Website-https://wafarifki.github.io-blue?" /></a>
    <a href="https://www.linkedin.com/in/wafarifqi/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-WafaRifqiAnafin_-blue" /></a>
    <a href="https://facebook.com/wafarifkianafin" target="_blank"><img src="https://img.shields.io/badge/Facebook-wafarifkianafin-blue" /></a>
    <a href="https://instagram.com/wafarifki_" target="_blank"><img src="https://img.shields.io/badge/Instagram-@wafarifki_-blue" /></a>
</p>
